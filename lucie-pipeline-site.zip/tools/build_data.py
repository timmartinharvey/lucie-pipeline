"""Turn an ArtifactData export (ideas/*.json, runs/*.json) into the site's data files.
Usage: python3 -I build_data.py <export_dir> <site_dir>
Keeps statuses.json and inbox.json untouched (those are Lucie's)."""
import json, glob, os, sys
src, site = sys.argv[1], sys.argv[2]
def load(p):
    d = json.load(open(p, encoding='utf-8')); return d.get('data', d)
ideas = []
for p in sorted(glob.glob(os.path.join(src, 'ideas', '*.json'))):
    d = load(p); d['id'] = os.path.basename(p)[:-5]; d.setdefault('runId', d['id'][:10]); ideas.append(d)
runs = sorted((load(p) for p in glob.glob(os.path.join(src, 'runs', '*.json'))), key=lambda r: r.get('date', ''), reverse=True)
json.dump(ideas, open(os.path.join(site, 'ideas.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(runs, open(os.path.join(site, 'runs.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for f, empty in (('statuses.json', {}), ('inbox.json', [])):
    p = os.path.join(site, f)
    if not os.path.exists(p): json.dump(empty, open(p, 'w'), indent=1)
print(len(ideas), 'ideas,', len(runs), 'runs')
